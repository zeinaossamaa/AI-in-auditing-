import { TrendingUp, TrendingDown, CheckCircle2, Clock, AlertCircle, Sparkles, BarChart3, Activity, RefreshCw } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ProgressData {
  totalHighRisk: number;
  reviewed: number;
  pending: number;
  percentComplete: number;
  riskTrendIndicator: 'Increasing' | 'Decreasing' | 'Stable';
  riskTrendPercentage: number;
}

interface Insight {
  category: string;
  finding: string;
  severity: 'High' | 'Medium' | 'Low';
  count: number;
}

const progressData: ProgressData = {
  totalHighRisk: 23,
  reviewed: 15,
  pending: 8,
  percentComplete: 65,
  riskTrendIndicator: 'Decreasing',
  riskTrendPercentage: 12,
};

// Real-time risk trend data
const riskTrendData = [
  { week: 'Week 1', highRisk: 45, mediumRisk: 78, avgRiskScore: 62 },
  { week: 'Week 2', highRisk: 38, mediumRisk: 72, avgRiskScore: 58 },
  { week: 'Week 3', highRisk: 31, mediumRisk: 65, avgRiskScore: 54 },
  { week: 'Week 4', highRisk: 23, mediumRisk: 58, avgRiskScore: 49 },
];

const aiInsights: Insight[] = [
  {
    category: 'Vendor Risk',
    finding: '12 transactions with new vendors lacking proper background verification',
    severity: 'High',
    count: 12,
  },
  {
    category: 'Timing Anomalies',
    finding: '8 transactions processed outside standard business hours',
    severity: 'Medium',
    count: 8,
  },
  {
    category: 'Amount Deviations',
    finding: '15 transactions exceed historical baseline by >200%',
    severity: 'High',
    count: 15,
  },
  {
    category: 'Duplicate Patterns',
    finding: '5 potential duplicate invoice numbers detected',
    severity: 'Medium',
    count: 5,
  },
  {
    category: 'Authorization Gaps',
    finding: '7 high-value transactions missing secondary approval',
    severity: 'High',
    count: 7,
  },
];

const recentActivity = [
  {
    id: 'TXN-2024-0923',
    action: 'Completed review',
    auditor: 'Sarah Chen',
    time: '2 hours ago',
    status: 'approved',
  },
  {
    id: 'TXN-2024-0847',
    action: 'Flagged for escalation',
    auditor: 'Michael Torres',
    time: '3 hours ago',
    status: 'flagged',
  },
  {
    id: 'TXN-2024-0856',
    action: 'Started review',
    auditor: 'Sarah Chen',
    time: '4 hours ago',
    status: 'in-progress',
  },
  {
    id: 'TXN-2024-0789',
    action: 'Completed review',
    auditor: 'James Liu',
    time: '5 hours ago',
    status: 'approved',
  },
];

export default function AuditExecution() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold mb-2">Audit Execution</h2>
          <p className="text-gray-600">Real-time progress monitoring and dynamic priority adjustment</p>
        </div>
      </div>

      {/* INPUT SECTION */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-lg p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-600 rounded-lg flex items-center justify-center">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">INPUT: Review Configuration</h3>
              <p className="text-sm text-amber-700 font-medium">Control audit execution parameters</p>
            </div>
            <span className="ml-3 px-3 py-1 bg-amber-600 text-white text-xs font-bold rounded-full">
              INPUT
            </span>
          </div>
          <button className="flex items-center gap-2 px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors font-bold shadow-md">
            <RefreshCw className="w-5 h-5" />
            Refresh Analytics
          </button>
        </div>
      </div>

      {/* OUTPUT SECTION */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-400 rounded-lg p-1">
        <div className="flex items-center gap-3 px-5 py-3 bg-blue-600 text-white rounded-t-lg">
          <Sparkles className="w-6 h-6" />
          <div className="flex-1">
            <h3 className="font-bold text-lg">OUTPUT: Real-Time AI Analytics Dashboard</h3>
            <p className="text-sm text-blue-100">Automated progress tracking and risk trend analysis</p>
          </div>
          <span className="px-3 py-1 bg-white text-blue-600 text-xs font-bold rounded-full">
            AI OUTPUT
          </span>
        </div>
        <div className="p-5 space-y-6">

      {/* EXE-01: Real-Time Analytics Dashboard - Field Requirements */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white border-2 border-blue-300 rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <p className="text-xs text-gray-600 mb-1 font-medium">Total High-Risk</p>
          <p className="text-3xl font-semibold text-gray-900">{progressData.totalHighRisk}</p>
          <p className="text-xs text-blue-600 mt-2">Requires Review</p>
        </div>

        <div className="bg-white border-2 border-green-300 rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <p className="text-xs text-gray-600 mb-1 font-medium">Transactions Reviewed</p>
          <p className="text-3xl font-semibold text-green-600">{progressData.reviewed}</p>
          <p className="text-xs text-green-600 mt-2">Completed</p>
        </div>

        <div className="bg-white border-2 border-yellow-300 rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
          <p className="text-xs text-gray-600 mb-1 font-medium">High-Risk Remaining</p>
          <p className="text-3xl font-semibold text-yellow-600">{progressData.pending}</p>
          <p className="text-xs text-yellow-600 mt-2">Pending Review</p>
        </div>

        <div className="bg-white border-2 border-purple-300 rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <Activity className="w-6 h-6 text-purple-600" />
            </div>
          </div>
          <p className="text-xs text-gray-600 mb-1 font-medium">Audit Progress (%)</p>
          <p className="text-3xl font-semibold text-purple-600">{progressData.percentComplete}%</p>
          <p className="text-xs text-purple-600 mt-2">Overall Completion</p>
        </div>

        <div className={`bg-white border-2 rounded-lg p-5 ${
          progressData.riskTrendIndicator === 'Decreasing'
            ? 'border-green-400 bg-green-50'
            : progressData.riskTrendIndicator === 'Increasing'
            ? 'border-red-400 bg-red-50'
            : 'border-gray-400 bg-gray-50'
        }`}>
          <div className="flex items-center justify-between mb-3">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
              progressData.riskTrendIndicator === 'Decreasing'
                ? 'bg-green-100'
                : progressData.riskTrendIndicator === 'Increasing'
                ? 'bg-red-100'
                : 'bg-gray-100'
            }`}>
              {progressData.riskTrendIndicator === 'Decreasing' ? (
                <TrendingDown className="w-6 h-6 text-green-600" />
              ) : progressData.riskTrendIndicator === 'Increasing' ? (
                <TrendingUp className="w-6 h-6 text-red-600" />
              ) : (
                <Activity className="w-6 h-6 text-gray-600" />
              )}
            </div>
          </div>
          <p className="text-xs text-gray-600 mb-1 font-medium">Risk Trend Indicator</p>
          <p className={`text-2xl font-bold ${
            progressData.riskTrendIndicator === 'Decreasing'
              ? 'text-green-600'
              : progressData.riskTrendIndicator === 'Increasing'
              ? 'text-red-600'
              : 'text-gray-600'
          }`}>
            {progressData.riskTrendIndicator}
          </p>
          <p className={`text-xs mt-2 font-medium ${
            progressData.riskTrendIndicator === 'Decreasing'
              ? 'text-green-600'
              : 'text-red-600'
          }`}>
            {progressData.riskTrendIndicator === 'Decreasing' ? '↓' : '↑'} {progressData.riskTrendPercentage}% vs last period
          </p>
        </div>
      </div>

      {/* Real-Time Risk Trend Visualization */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <Activity className="w-6 h-6 text-blue-600" />
          <div>
            <h3 className="font-semibold">Real-Time Risk Trend Analysis</h3>
            <p className="text-sm text-gray-600">Dynamic monitoring for priority adjustment</p>
          </div>
        </div>
        {riskTrendData && riskTrendData.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={riskTrendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="highRisk" stroke="#DC2626" strokeWidth={2} name="High Risk Count" dot={{ r: 5 }} />
              <Line type="monotone" dataKey="mediumRisk" stroke="#F59E0B" strokeWidth={2} name="Medium Risk Count" dot={{ r: 5 }} />
              <Line type="monotone" dataKey="avgRiskScore" stroke="#3B82F6" strokeWidth={2} name="Avg Risk Score" dot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[300px] flex items-center justify-center bg-gray-50 rounded">
            <p className="text-gray-500">No trend data available</p>
          </div>
        )}
      </div>

      {/* Progress Bar */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="font-semibold mb-4">High-Risk Transaction Review Progress</h3>
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>
              {progressData.reviewed} of {progressData.totalHighRisk} reviewed
            </span>
            <span>{progressData.percentComplete}% complete</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div
              className="bg-gradient-to-r from-blue-600 to-purple-600 h-4 rounded-full transition-all duration-300"
              style={{ width: `${progressData.percentComplete}%` }}
            />
          </div>
          <div className="flex gap-4 pt-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm text-gray-600">Reviewed ({progressData.reviewed})</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full" />
              <span className="text-sm text-gray-600">Pending ({progressData.pending})</span>
            </div>
          </div>
        </div>
      </div>

      {/* EXE-02: AI-Supported Key Insights Summary */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-400 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900 text-lg">Key Insights Summary (AI-Generated)</h3>
            <p className="text-sm text-gray-600">Concise AI analysis identifying irregularities and patterns</p>
          </div>
        </div>

        {/* Executive Summary */}
        <div className="bg-white border border-blue-300 rounded-lg p-5 mb-4">
          <p className="text-xs font-bold text-blue-600 mb-2">EXECUTIVE SUMMARY</p>
          <p className="text-sm text-gray-700 leading-relaxed">
            AI analysis of {progressData.reviewed} reviewed high-risk transactions has identified {aiInsights.filter(i => i.severity === 'High').length} critical patterns requiring immediate attention.
            The risk trend is currently <strong className={progressData.riskTrendIndicator === 'Decreasing' ? 'text-green-600' : 'text-red-600'}>
              {progressData.riskTrendIndicator.toLowerCase()}
            </strong> by {progressData.riskTrendPercentage}%, suggesting {progressData.riskTrendIndicator === 'Decreasing' ? 'improved' : 'deteriorating'} control effectiveness.
            Key irregularities center around vendor verification gaps, authorization workflow deviations, and amount anomalies.
          </p>
        </div>

        {/* Detailed Insights */}
        <div className="space-y-3">
          {aiInsights.map((insight, index) => (
            <div
              key={index}
              className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span
                      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${
                        insight.severity === 'High'
                          ? 'bg-red-100 text-red-800 border border-red-300'
                          : insight.severity === 'Medium'
                          ? 'bg-yellow-100 text-yellow-800 border border-yellow-300'
                          : 'bg-blue-100 text-blue-800 border border-blue-300'
                      }`}
                    >
                      {insight.severity} PRIORITY
                    </span>
                    <h4 className="font-semibold text-gray-900">{insight.category}</h4>
                  </div>
                  <p className="text-sm text-gray-700">{insight.finding}</p>
                </div>
                <div className="flex-shrink-0 text-right">
                  <div className="text-3xl font-bold text-blue-600">{insight.count}</div>
                  <div className="text-xs text-gray-500 font-medium">instances</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* AI Confidence Indicator */}
        <div className="mt-4 bg-blue-100 border border-blue-300 rounded-lg p-3">
          <p className="text-xs font-semibold text-blue-900">
            ✓ AI Analysis Confidence: High | Pattern Recognition Accuracy: 94.2% | Last Updated: Real-time
          </p>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white border border-gray-200 rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
          <h3 className="font-semibold">Recent Audit Activity</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {recentActivity.map((activity, index) => (
            <div key={index} className="px-6 py-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  {activity.status === 'approved' ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                  ) : activity.status === 'flagged' ? (
                    <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
                  ) : (
                    <Clock className="w-5 h-5 text-yellow-600 mt-0.5" />
                  )}
                  <div>
                    <p className="font-medium text-gray-900">
                      {activity.id} - {activity.action}
                    </p>
                    <p className="text-sm text-gray-600 mt-1">by {activity.auditor}</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">{activity.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Analytics Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border-2 border-blue-300 rounded-lg p-5">
          <p className="text-sm text-gray-600 mb-2">Avg Review Time</p>
          <p className="text-2xl font-semibold text-gray-900">24 min</p>
          <p className="text-xs text-green-600 mt-1 font-medium">↓ 15% from last period</p>
        </div>
        <div className="bg-white border-2 border-blue-300 rounded-lg p-5">
          <p className="text-sm text-gray-600 mb-2">Escalation Rate</p>
          <p className="text-2xl font-semibold text-gray-900">18%</p>
          <p className="text-xs text-yellow-600 mt-1 font-medium">↑ 3% from last period</p>
        </div>
        <div className="bg-white border-2 border-blue-300 rounded-lg p-5">
          <p className="text-sm text-gray-600 mb-2">AI Accuracy</p>
          <p className="text-2xl font-semibold text-gray-900">94.2%</p>
          <p className="text-xs text-green-600 mt-1 font-medium">↑ 2.1% from last period</p>
        </div>
      </div>
        </div>
      </div>
    </div>
  );
}
