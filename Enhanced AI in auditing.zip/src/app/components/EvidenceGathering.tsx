import { AlertTriangle, CheckCircle, FileText, MessageSquare, Sparkles, TrendingUp, TrendingDown, Activity } from 'lucide-react';
import { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from 'recharts';

interface TransactionDetail {
  id: string;
  amount: number;
  date: string;
  vendor: string;
  category: string;
  riskScore: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  anomalyFlag: 'Yes' | 'No';
  anomalyType: string[];
  anomalies: string[];
  aiSummary: string;
  aiExplanation: string;
  auditChecks: {
    name: string;
    status: 'Completed' | 'Pending' | 'Failed';
    auditorNote: string;
  }[];
  auditNotes: string[];
}

const mockTransaction: TransactionDetail = {
  id: 'TXN-2024-0847',
  amount: 245000,
  date: '2024-05-15',
  vendor: 'Tech Solutions Ltd.',
  category: 'Wire Transfer',
  riskScore: 94,
  riskLevel: 'High',
  anomalyFlag: 'Yes',
  anomalyType: ['Amount Deviation', 'Timing Anomaly', 'Vendor Account Change'],
  anomalies: [
    'Amount exceeds historical average by 340%',
    'Unusual payment timing (outside normal business hours)',
    'Vendor bank account changed within last 30 days',
  ],
  aiSummary: 'This transaction shows multiple red flags including significant deviation from historical patterns, unusual timing, and recent vendor account changes. The ML model has identified this as requiring immediate manual review. Historical data shows this vendor typically receives payments of $55,000-$72,000. The current amount of $245,000 is substantially higher and occurred outside the standard approval workflow.',
  aiExplanation: 'ML Risk Model Confidence: 94% | Pattern Analysis: Statistical outlier detected using Z-score analysis (3.4 standard deviations above mean) | Behavioral Analysis: Transaction deviates from established vendor payment patterns | Temporal Analysis: Processed at 11:47 PM, outside typical business hours (9 AM - 6 PM)',
  auditChecks: [
    {
      name: 'Vendor Verification',
      status: 'Completed',
      auditorNote: 'Verified vendor registration and tax ID',
    },
    {
      name: 'Authorization Review',
      status: 'Pending',
      auditorNote: '',
    },
    {
      name: 'Supporting Documentation',
      status: 'Completed',
      auditorNote: 'Invoice and PO attached, amounts match',
    },
    {
      name: 'Compliance Check',
      status: 'Pending',
      auditorNote: '',
    },
  ],
  auditNotes: [
    'Initial review: Amount is for annual software license renewal, explains the increase',
    'Contacted vendor to verify bank account change - legitimate update confirmed',
  ],
};

// Transaction pattern data for visualization
const transactionTrendData = [
  { date: '05/01', amount: 58000, avgAmount: 62000, riskScore: 28 },
  { date: '05/03', amount: 72000, avgAmount: 62000, riskScore: 35 },
  { date: '05/05', amount: 55000, avgAmount: 62000, riskScore: 22 },
  { date: '05/07', amount: 68000, avgAmount: 62000, riskScore: 31 },
  { date: '05/09', amount: 61000, avgAmount: 62000, riskScore: 25 },
  { date: '05/11', amount: 59000, avgAmount: 62000, riskScore: 27 },
  { date: '05/13', amount: 71000, avgAmount: 62000, riskScore: 33 },
  { date: '05/15', amount: 245000, avgAmount: 62000, riskScore: 94 },
];

const anomalyTypeDistribution = [
  { type: 'Amount Deviation', count: 15, severity: 'High' },
  { type: 'Timing Anomaly', count: 8, severity: 'Medium' },
  { type: 'Vendor Risk', count: 12, severity: 'High' },
  { type: 'Authorization Gap', count: 7, severity: 'High' },
  { type: 'Duplicate Pattern', count: 5, severity: 'Medium' },
];

export default function EvidenceGathering() {
  const [newNote, setNewNote] = useState('');
  const [notes, setNotes] = useState<string[]>(mockTransaction.auditNotes || []);

  const handleAddNote = () => {
    if (newNote.trim()) {
      setNotes([...notes, newNote]);
      setNewNote('');
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold mb-2">Evidence Gathering</h2>
        <p className="text-gray-600">Interactive transaction analysis with AI-powered anomaly detection and pattern visualization</p>
      </div>

      {/* OUTPUT SECTION: AI Analytics */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-400 rounded-lg p-1">
        <div className="flex items-center gap-3 px-5 py-3 bg-blue-600 text-white rounded-t-lg">
          <Sparkles className="w-6 h-6" />
          <div className="flex-1">
            <h3 className="font-bold text-lg">OUTPUT: AI-Generated Analysis & Insights</h3>
            <p className="text-sm text-blue-100">Machine learning anomaly detection and pattern recognition</p>
          </div>
          <span className="px-3 py-1 bg-white text-blue-600 text-xs font-bold rounded-full">
            AI OUTPUT
          </span>
        </div>

      {/* EVD-01: Interactive Pattern Visualization Dashboard */}
      <div className="p-5">
      <div className="bg-white border-2 border-blue-300 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <Activity className="w-6 h-6 text-blue-600" />
          <div>
            <h3 className="text-lg font-semibold">Transaction Pattern Analysis</h3>
            <p className="text-sm text-gray-600">Interactive visualization of trends and anomalies</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Amount Trend Chart */}
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-4">Amount Trend vs Historical Average</h4>
            {transactionTrendData && transactionTrendData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={transactionTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip formatter={(value) => value ? `$${Number(value).toLocaleString()}` : '$0'} />
                  <Legend />
                  <Area type="monotone" dataKey="avgAmount" stroke="#9CA3AF" fill="#E5E7EB" name="Historical Avg" />
                  <Area type="monotone" dataKey="amount" stroke="#3B82F6" fill="#93C5FD" name="Transaction Amount" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[250px] flex items-center justify-center bg-gray-50 rounded">
                <p className="text-gray-500">No data available</p>
              </div>
            )}
          </div>

          {/* Risk Score Trend */}
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-4">Risk Score Progression</h4>
            {transactionTrendData && transactionTrendData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={transactionTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="riskScore" stroke="#DC2626" strokeWidth={2} name="Risk Score" dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[250px] flex items-center justify-center bg-gray-50 rounded">
                <p className="text-gray-500">No data available</p>
              </div>
            )}
          </div>
        </div>

        {/* Anomaly Type Distribution */}
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-4">Anomaly Type Distribution</h4>
          {anomalyTypeDistribution && anomalyTypeDistribution.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={anomalyTypeDistribution} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis type="category" dataKey="type" width={150} />
                <Tooltip />
                <Legend />
                <Bar dataKey="count" fill="#F59E0B" name="Occurrences" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[200px] flex items-center justify-center bg-gray-50 rounded">
              <p className="text-gray-500">No data available</p>
            </div>
          )}
        </div>
      </div>

      {/* Transaction Overview with Field Requirements */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-lg font-semibold">Transaction {mockTransaction.id}</h3>
              {mockTransaction.anomalyFlag === 'Yes' && (
                <div className="flex items-center gap-2 px-3 py-1 bg-red-100 border-2 border-red-500 rounded-lg animate-pulse">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                  <span className="text-sm font-bold text-red-800">ANOMALY DETECTED</span>
                </div>
              )}
            </div>
            <p className="text-sm text-gray-600">{mockTransaction.vendor}</p>
          </div>
          <span
            className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
              mockTransaction.riskLevel === 'High'
                ? 'bg-red-100 text-red-800 border border-red-300'
                : mockTransaction.riskLevel === 'Medium'
                ? 'bg-yellow-100 text-yellow-800 border border-yellow-300'
                : 'bg-green-100 text-green-800 border border-green-300'
            }`}
          >
            {mockTransaction.riskLevel} Risk
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div>
            <p className="text-sm text-gray-600 mb-1">Transaction ID</p>
            <p className="text-lg font-semibold">{mockTransaction.id}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Amount</p>
            <p className="text-lg font-semibold">${mockTransaction.amount.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Date</p>
            <p className="text-lg font-semibold">{mockTransaction.date}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Category</p>
            <p className="text-lg font-semibold">{mockTransaction.category}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">AI Risk Score</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-gray-200 rounded-full h-3">
                <div
                  className="h-3 rounded-full bg-red-600"
                  style={{ width: `${mockTransaction.riskScore}%` }}
                />
              </div>
              <span className="text-lg font-semibold">{mockTransaction.riskScore}</span>
            </div>
          </div>
        </div>

        {/* Anomaly Flag and Type */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-gray-200">
          <div>
            <p className="text-sm text-gray-600 mb-2">Anomaly Flag</p>
            <span className={`inline-flex items-center px-4 py-2 rounded-lg text-sm font-bold ${
              mockTransaction.anomalyFlag === 'Yes'
                ? 'bg-red-100 text-red-800 border-2 border-red-500'
                : 'bg-green-100 text-green-800 border-2 border-green-500'
            }`}>
              {mockTransaction.anomalyFlag === 'Yes' ? '⚠ YES - FLAGGED' : '✓ NO'}
            </span>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-2">Anomaly Types</p>
            <div className="flex flex-wrap gap-2">
              {mockTransaction.anomalyType.map((type, index) => (
                <span key={index} className="px-3 py-1 bg-red-50 border border-red-300 text-red-800 rounded-md text-xs font-medium">
                  {type}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* EVD-03: Anomaly Flags with Warning Indicators */}
      <div className="bg-red-50 border-2 border-red-500 rounded-lg p-5 shadow-lg">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center flex-shrink-0 animate-pulse">
            <AlertTriangle className="w-7 h-7 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <h4 className="font-bold text-red-900 text-lg">⚠ SUSPICIOUS TRANSACTION - FLAGGED FOR INVESTIGATION</h4>
            </div>
            <p className="text-sm text-red-800 mb-4 font-medium">
              This transaction has been automatically flagged by the AI system for potential fraud investigation.
              Multiple anomaly types detected requiring immediate forensic review.
            </p>
            <div className="space-y-3">
              {mockTransaction.anomalies.map((anomaly, index) => (
                <div key={index} className="flex items-start gap-3 bg-white border-l-4 border-red-600 p-3 rounded">
                  <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-red-900">
                      {mockTransaction.anomalyType[index] || 'Anomaly Detected'}
                    </p>
                    <p className="text-sm text-gray-700 mt-1">{anomaly}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* EVD-02: NLP-Generated Summaries and Explainable AI Insights */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-300 rounded-lg p-5">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-gray-900 mb-3">NLP-Generated Summary & AI Insights</h4>
            <div className="space-y-4">
              <div className="bg-white border border-blue-200 rounded-lg p-4">
                <p className="text-xs font-semibold text-blue-600 mb-2">AI SUMMARY (Natural Language Processing)</p>
                <p className="text-sm text-gray-700 leading-relaxed">{mockTransaction.aiSummary}</p>
              </div>
              <div className="bg-white border border-blue-200 rounded-lg p-4">
                <p className="text-xs font-semibold text-blue-600 mb-2">EXPLAINABLE AI - MODEL EXPLANATION</p>
                <p className="text-sm text-gray-700 leading-relaxed">{mockTransaction.aiExplanation}</p>
              </div>
              <div className="bg-blue-100 border border-blue-300 rounded-lg p-3">
                <p className="text-xs font-semibold text-blue-900 mb-1">✓ VALIDATION STATUS</p>
                <p className="text-xs text-blue-900">
                  AI findings are presented for auditor review and validation. All AI-generated insights require human verification before final determination.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      </div>
      </div>

      {/* INPUT SECTION: Human Auditor Actions */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-lg p-1">
        <div className="flex items-center gap-3 px-5 py-3 bg-amber-600 text-white rounded-t-lg">
          <MessageSquare className="w-6 h-6" />
          <div className="flex-1">
            <h3 className="font-bold text-lg">INPUT: Auditor Review & Documentation</h3>
            <p className="text-sm text-amber-100">Human-controlled audit checks and professional notes</p>
          </div>
          <span className="px-3 py-1 bg-white text-amber-600 text-xs font-bold rounded-full">
            INPUT
          </span>
        </div>
        <div className="p-5 space-y-5">

      {/* Audit Checks with Status (Completed/Pending) */}
      <div className="bg-white border-2 border-amber-300 rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Audit Check Status (Completed / Pending)</h3>
            <div className="flex gap-3 text-sm">
              <span className="text-green-600 font-medium">
                ✓ {mockTransaction.auditChecks.filter(c => c.status === 'Completed').length} Completed
              </span>
              <span className="text-yellow-600 font-medium">
                ⏳ {mockTransaction.auditChecks.filter(c => c.status === 'Pending').length} Pending
              </span>
            </div>
          </div>
        </div>
        <div className="p-6 space-y-4">
          {mockTransaction.auditChecks.map((check, index) => (
            <div
              key={index}
              className={`flex items-start gap-4 p-4 border-2 rounded-lg ${
                check.status === 'Completed'
                  ? 'border-green-300 bg-green-50'
                  : check.status === 'Pending'
                  ? 'border-yellow-300 bg-yellow-50'
                  : 'border-red-300 bg-red-50'
              }`}
            >
              <div className="flex-shrink-0">
                {check.status === 'Completed' ? (
                  <CheckCircle className="w-7 h-7 text-green-600" />
                ) : check.status === 'Failed' ? (
                  <AlertTriangle className="w-7 h-7 text-red-600" />
                ) : (
                  <div className="w-7 h-7 border-3 border-yellow-500 rounded-full flex items-center justify-center">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h5 className="font-semibold text-gray-900">{check.name}</h5>
                  <span
                    className={`text-xs font-bold px-3 py-1.5 rounded-full ${
                      check.status === 'Completed'
                        ? 'bg-green-600 text-white'
                        : check.status === 'Failed'
                        ? 'bg-red-600 text-white'
                        : 'bg-yellow-600 text-white'
                    }`}
                  >
                    {check.status.toUpperCase()}
                  </span>
                </div>
                {check.auditorNote && (
                  <div className="bg-white border border-blue-200 rounded p-3 mt-2">
                    <p className="text-xs text-gray-600 mb-1 font-medium">Audit Notes:</p>
                    <p className="text-sm text-gray-700">{check.auditorNote}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Audit Notes (Human Input) */}
      <div className="bg-white border-2 border-amber-300 rounded-lg">
        <div className="px-6 py-4 border-b-2 border-amber-300 bg-amber-100">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-700" />
            <h3 className="font-bold text-amber-900">Professional Audit Notes</h3>
          </div>
          <p className="text-xs text-amber-700 mt-1">Document findings, observations, and audit trail</p>
        </div>
        <div className="p-6 space-y-4">
          {notes.map((note, index) => (
            <div key={index} className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <FileText className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs font-semibold text-amber-700 mb-1">AUDITOR NOTE #{index + 1}</p>
                  <p className="text-sm text-gray-700">{note}</p>
                </div>
              </div>
            </div>
          ))}

          <div className="space-y-3 pt-4 border-t border-gray-200">
            <label className="block text-sm font-medium text-gray-700">
              Add New Audit Note
            </label>
            <textarea
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              placeholder="Enter your audit note here..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none resize-none"
              rows={3}
            />
            <button
              onClick={handleAddNote}
              className="px-6 py-2.5 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors font-bold shadow-md"
            >
              Add Audit Note
            </button>
          </div>
        </div>
      </div>
        </div>
      </div>
    </div>
  );
}
