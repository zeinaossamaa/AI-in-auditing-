import { AlertCircle, TrendingUp, Filter, Search, Sparkles, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

interface Transaction {
  id: string;
  amount: number;
  date: string;
  riskScore: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  category: string;
  priorityLevel: number;
  status: 'Reviewed' | 'Pending';
  aiExplanation: string;
}

const mockTransactions: Transaction[] = [
  {
    id: 'TXN-2024-0847',
    amount: 245000,
    date: '2024-05-15',
    riskScore: 94,
    riskLevel: 'High',
    category: 'Wire Transfer',
    priorityLevel: 1,
    status: 'Pending',
    aiExplanation: 'Unusual amount for this vendor, exceeds historical average by 340%'
  },
  {
    id: 'TXN-2024-0923',
    amount: 89500,
    date: '2024-05-14',
    riskScore: 87,
    riskLevel: 'High',
    category: 'Procurement',
    priorityLevel: 2,
    status: 'Pending',
    aiExplanation: 'New vendor with no prior transaction history, high amount'
  },
  {
    id: 'TXN-2024-0856',
    amount: 12400,
    date: '2024-05-13',
    riskScore: 72,
    riskLevel: 'Medium',
    category: 'Expense Reimbursement',
    priorityLevel: 3,
    status: 'Pending',
    aiExplanation: 'Duplicate invoice number detected in different periods'
  },
  {
    id: 'TXN-2024-0789',
    amount: 156000,
    date: '2024-05-12',
    riskScore: 68,
    riskLevel: 'Medium',
    category: 'Contract Payment',
    priorityLevel: 4,
    status: 'Reviewed',
    aiExplanation: 'Payment timing deviates from contract schedule by 15 days'
  },
  {
    id: 'TXN-2024-0654',
    amount: 4500,
    date: '2024-05-11',
    riskScore: 28,
    riskLevel: 'Low',
    category: 'Supplies',
    priorityLevel: 5,
    status: 'Pending',
    aiExplanation: 'Standard transaction within normal parameters'
  },
];

export default function AuditPlanning() {
  const [filterRisk, setFilterRisk] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [uploadedFile, setUploadedFile] = useState<string>('');

  const filteredTransactions = mockTransactions.filter(txn => {
    const matchesRisk = filterRisk === 'all' || txn.riskLevel === filterRisk;
    const matchesSearch = txn.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         txn.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesRisk && matchesSearch;
  });

  const highRiskCount = mockTransactions.filter(t => t.riskLevel === 'High').length;
  const mediumRiskCount = mockTransactions.filter(t => t.riskLevel === 'Medium').length;
  const avgRiskScore = Math.round(mockTransactions.reduce((sum, t) => sum + t.riskScore, 0) / mockTransactions.length);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file.name);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold mb-2">Audit Planning</h2>
        <p className="text-gray-600">AI-powered risk assessment and transaction prioritization</p>
      </div>

      {/* INPUT SECTION */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 bg-amber-600 rounded-lg flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900 text-lg">INPUT: Upload & Configure Audit Scope</h3>
            <p className="text-sm text-amber-700 font-medium">Auditor-controlled data input and filtering</p>
          </div>
          <span className="ml-auto px-3 py-1 bg-amber-600 text-white text-xs font-bold rounded-full">
            INPUT
          </span>
        </div>

        {/* File Upload */}
        <div className="bg-white border-2 border-amber-300 rounded-lg p-5 mb-4">
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            Upload Transaction Dataset (CSV, Excel)
          </label>
          <div className="flex items-center gap-4">
            <label className="flex-1 cursor-pointer">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 hover:border-amber-500 hover:bg-amber-50 transition-colors">
                <div className="text-center">
                  <TrendingUp className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-sm font-medium text-gray-700 mb-1">
                    {uploadedFile || 'Click to upload or drag and drop'}
                  </p>
                  <p className="text-xs text-gray-500">CSV, XLSX, XLS up to 50MB</p>
                </div>
                <input
                  type="file"
                  accept=".csv,.xlsx,.xls"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            </label>
          </div>
          {uploadedFile && (
            <div className="mt-3 flex items-center gap-2 text-sm text-green-700 bg-green-50 border border-green-200 rounded p-3">
              <CheckCircle2 className="w-5 h-5" />
              <span className="font-medium">File uploaded: {uploadedFile}</span>
            </div>
          )}
        </div>

        {/* Filters and Search */}
        <div className="bg-white border-2 border-amber-300 rounded-lg p-5">
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            Filter & Search Transactions
          </label>
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-gray-400" />
                <span className="text-sm font-medium">Risk Level:</span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setFilterRisk('all')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    filterRisk === 'all'
                      ? 'bg-amber-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilterRisk('High')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    filterRisk === 'High'
                      ? 'bg-red-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  High Risk
                </button>
                <button
                  onClick={() => setFilterRisk('Medium')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    filterRisk === 'Medium'
                      ? 'bg-yellow-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Medium Risk
                </button>
                <button
                  onClick={() => setFilterRisk('Low')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    filterRisk === 'Low'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Low Risk
                </button>
              </div>
            </div>
            <div className="flex items-center gap-2 border-2 border-gray-300 rounded-md px-3 py-2 bg-white">
              <Search className="w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search by Transaction ID or Category..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="outline-none text-sm flex-1"
              />
            </div>
          </div>
        </div>
      </div>

      {/* OUTPUT SECTION */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-400 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900 text-lg">OUTPUT: AI-Generated Risk Assessment</h3>
            <p className="text-sm text-blue-700 font-medium">Machine learning risk scores and prioritization</p>
          </div>
          <span className="ml-auto px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-full">
            AI OUTPUT
          </span>
        </div>

        {/* Summary Cards - AI Analytics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-5">
          <div className="bg-white border-2 border-blue-300 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Transactions</p>
                <p className="text-2xl font-semibold mt-1">{mockTransactions.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white border-2 border-red-400 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">High Risk</p>
                <p className="text-2xl font-semibold mt-1 text-red-600">{highRiskCount}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-red-600" />
              </div>
            </div>
            <div className="mt-2 text-xs text-gray-500 bg-blue-100 border border-blue-300 rounded px-2 py-1">
              AI-Generated Priority
            </div>
          </div>

          <div className="bg-white border-2 border-yellow-400 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Medium Risk</p>
                <p className="text-2xl font-semibold mt-1 text-yellow-600">{mediumRiskCount}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
            <div className="mt-2 text-xs text-gray-500 bg-blue-100 border border-blue-300 rounded px-2 py-1">
              AI-Generated Priority
            </div>
          </div>

          <div className="bg-white border-2 border-purple-400 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Risk Score</p>
                <p className="text-2xl font-semibold mt-1">{avgRiskScore}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <div className="mt-2 text-xs text-gray-500 bg-blue-100 border border-blue-300 rounded px-2 py-1">
              AI-Calculated Average
            </div>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="bg-white border-2 border-blue-300 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-blue-200 bg-blue-50">
          <h3 className="font-semibold">AI-Prioritized Transactions Dashboard</h3>
          <p className="text-xs text-blue-700 mt-1">High-risk transactions automatically ranked by ML risk model</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Priority
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Transaction ID
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Category
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Risk Score
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Risk Level
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredTransactions.map((txn) => (
                <tr
                  key={txn.id}
                  className={`hover:bg-gray-50 ${
                    txn.riskLevel === 'High' ? 'bg-red-50' : ''
                  }`}
                >
                  <td className="px-4 py-4 whitespace-nowrap">
                    <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-blue-600 text-white text-sm font-medium">
                      {txn.priorityLevel}
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {txn.id}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">
                    {txn.date}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">
                    {txn.category}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-medium">
                    ${txn.amount.toLocaleString()}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2 w-20">
                        <div
                          className={`h-2 rounded-full ${
                            txn.riskScore >= 80
                              ? 'bg-red-600'
                              : txn.riskScore >= 50
                              ? 'bg-yellow-500'
                              : 'bg-green-500'
                          }`}
                          style={{ width: `${txn.riskScore}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium text-gray-900 w-8">
                        {txn.riskScore}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        txn.riskLevel === 'High'
                          ? 'bg-red-100 text-red-800'
                          : txn.riskLevel === 'Medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                      }`}
                    >
                      {txn.riskLevel}
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        txn.status === 'Reviewed'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {txn.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

        {/* AI Explanations */}
        <div className="bg-white border-2 border-blue-300 rounded-lg p-5 mt-5">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900 mb-3">AI Risk Insights & Explanations</h4>
              <p className="text-xs text-blue-700 mb-3 font-medium">Top priority transactions with ML-generated risk rationale</p>
              <div className="space-y-2">
                {filteredTransactions.slice(0, 3).map((txn) => (
                  <div key={txn.id} className="text-sm text-gray-700 bg-blue-50 border-l-4 border-blue-600 p-3 rounded">
                    <span className="font-bold">{txn.id}:</span> {txn.aiExplanation}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
