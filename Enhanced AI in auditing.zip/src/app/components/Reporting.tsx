import { FileText, Download, Edit3, TrendingUp, AlertCircle } from 'lucide-react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useState } from 'react';

const riskDistributionData = [
  { name: 'High Risk', value: 23, color: '#DC2626' },
  { name: 'Medium Risk', value: 45, color: '#F59E0B' },
  { name: 'Low Risk', value: 132, color: '#10B981' },
];

const anomalyData = [
  { category: 'Vendor Risk', count: 12 },
  { category: 'Amount Deviation', count: 15 },
  { category: 'Timing', count: 8 },
  { category: 'Authorization', count: 7 },
  { category: 'Duplicates', count: 5 },
];

interface Recommendation {
  id: number;
  text: string;
  priority: 'High' | 'Medium' | 'Low';
  isEditing: boolean;
  editedText: string;
}

const initialRecommendations: Recommendation[] = [
  {
    id: 1,
    text: 'Implement mandatory dual authorization for all transactions exceeding $100,000',
    priority: 'High',
    isEditing: false,
    editedText: '',
  },
  {
    id: 2,
    text: 'Enhance vendor background verification process for new suppliers',
    priority: 'High',
    isEditing: false,
    editedText: '',
  },
  {
    id: 3,
    text: 'Establish automated alerts for transactions processed outside business hours',
    priority: 'Medium',
    isEditing: false,
    editedText: '',
  },
  {
    id: 4,
    text: 'Conduct quarterly reviews of historical transaction patterns for all vendors',
    priority: 'Medium',
    isEditing: false,
    editedText: '',
  },
];

export default function Reporting() {
  const [recommendations, setRecommendations] = useState<Recommendation[]>(initialRecommendations || []);
  const [auditorComment, setAuditorComment] = useState('');
  const [savedComments, setSavedComments] = useState<string[]>([]);
  const [reportTitle, setReportTitle] = useState('Q2 2024 Transaction Audit Report');
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [auditStartDate, setAuditStartDate] = useState('2024-05-01');
  const [auditEndDate, setAuditEndDate] = useState('2024-05-15');

  const handleEditRecommendation = (id: number) => {
    setRecommendations(
      recommendations.map((rec) =>
        rec.id === id
          ? { ...rec, isEditing: true, editedText: rec.text }
          : rec
      )
    );
  };

  const handleSaveRecommendation = (id: number) => {
    setRecommendations(
      recommendations.map((rec) =>
        rec.id === id
          ? { ...rec, isEditing: false, text: rec.editedText }
          : rec
      )
    );
  };

  const handleCancelEdit = (id: number) => {
    setRecommendations(
      recommendations.map((rec) =>
        rec.id === id ? { ...rec, isEditing: false, editedText: '' } : rec
      )
    );
  };

  const handleAddComment = () => {
    if (auditorComment.trim()) {
      setSavedComments([...savedComments, auditorComment]);
      setAuditorComment('');
    }
  };

  const totalTransactions = 200;
  const highRiskPercentage = ((23 / totalTransactions) * 100).toFixed(1);
  const mediumRiskPercentage = ((45 / totalTransactions) * 100).toFixed(1);
  const lowRiskPercentage = ((132 / totalTransactions) * 100).toFixed(1);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold mb-2">Audit Report Generation</h2>
          <p className="text-gray-600">AI-generated structured reports with human oversight</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-bold shadow-md">
          <Download className="w-5 h-5" />
          Export Report
        </button>
      </div>

      {/* INPUT SECTION */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-lg p-1">
        <div className="flex items-center gap-3 px-5 py-3 bg-amber-600 text-white rounded-t-lg">
          <Edit3 className="w-6 h-6" />
          <div className="flex-1">
            <h3 className="font-bold text-lg">INPUT: Report Configuration & Human Review</h3>
            <p className="text-sm text-amber-100">Auditor-controlled report parameters and professional input</p>
          </div>
          <span className="px-3 py-1 bg-white text-amber-600 text-xs font-bold rounded-full">
            INPUT
          </span>
        </div>
        <div className="p-5 space-y-5">

      {/* RPT-01 & RPT-02: Report Title (Editable) */}
      <div className="bg-white border-2 border-amber-300 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <label className="text-sm font-semibold text-gray-700 uppercase tracking-wide">Report Title</label>
          <button
            onClick={() => setIsEditingTitle(!isEditingTitle)}
            className="text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
          >
            <Edit3 className="w-4 h-4" />
            {isEditingTitle ? 'Save' : 'Edit'}
          </button>
        </div>
        {isEditingTitle ? (
          <input
            type="text"
            value={reportTitle}
            onChange={(e) => setReportTitle(e.target.value)}
            onBlur={() => setIsEditingTitle(false)}
            className="w-full text-2xl font-bold text-gray-900 border-b-2 border-blue-500 focus:outline-none pb-2"
            autoFocus
          />
        ) : (
          <h1 className="text-3xl font-bold text-gray-900">{reportTitle}</h1>
        )}
      </div>

      {/* RPT-01: Audit Period (Start Date – End Date) */}
      <div className="bg-white border-2 border-amber-300 rounded-lg p-6">
        <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-4">Audit Period</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4">
            <label className="text-xs font-medium text-amber-700 mb-2 block">Start Date</label>
            <input
              type="date"
              value={auditStartDate}
              onChange={(e) => setAuditStartDate(e.target.value)}
              className="w-full text-lg font-semibold text-gray-900 bg-transparent border-b-2 border-amber-400 focus:outline-none focus:border-amber-600 pb-1"
            />
          </div>
          <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4">
            <label className="text-xs font-medium text-amber-700 mb-2 block">End Date</label>
            <input
              type="date"
              value={auditEndDate}
              onChange={(e) => setAuditEndDate(e.target.value)}
              className="w-full text-lg font-semibold text-gray-900 bg-transparent border-b-2 border-amber-400 focus:outline-none focus:border-amber-600 pb-1"
            />
          </div>
          <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4 flex items-center justify-center">
            <div className="text-center">
              <p className="text-xs font-medium text-amber-700 mb-1">Duration</p>
              <p className="text-2xl font-bold text-amber-900">15 Days</p>
            </div>
          </div>
        </div>
      </div>

        </div>
      </div>

      {/* OUTPUT SECTION */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-400 rounded-lg p-1">
        <div className="flex items-center gap-3 px-5 py-3 bg-blue-600 text-white rounded-t-lg">
          <FileText className="w-6 h-6" />
          <div className="flex-1">
            <h3 className="font-bold text-lg">OUTPUT: AI-Generated Report Content</h3>
            <p className="text-sm text-blue-100">Automated analysis, findings, and risk assessments</p>
          </div>
          <span className="px-3 py-1 bg-white text-blue-600 text-xs font-bold rounded-full">
            AI OUTPUT
          </span>
        </div>
        <div className="p-5 space-y-5">

      {/* RPT-01: Summary of Findings (AI-Generated) */}
      <div className="bg-white border-2 border-blue-300 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold text-gray-900">Summary of Findings (AI-Generated)</h3>
            <p className="text-xs text-blue-700 font-medium mt-1">Natural Language Processing Summary</p>
          </div>
          <span className="px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-full">
            AI OUTPUT
          </span>
        </div>
        <div className="space-y-4 text-sm text-gray-700 leading-relaxed bg-white border border-blue-200 rounded-lg p-5">
          <div>
            <p className="font-semibold text-gray-900 mb-2">Audit Scope & Coverage:</p>
            <p>
              The AI-assisted audit of transaction data for the period covering {auditStartDate} to {auditEndDate}
              has identified 23 high-risk transactions requiring immediate attention. The audit
              encompassed 200 total transactions with a combined value of $12.4M across multiple
              transaction categories including wire transfers, procurement, expense reimbursements,
              and contract payments.
            </p>
          </div>
          <div>
            <p className="font-semibold text-gray-900 mb-2">Key Findings:</p>
            <p>
              Machine learning algorithms detected significant patterns including vendor
              verification gaps (12 instances), unusual payment timing (8 instances), and
              authorization workflow deviations (7 instances). The most prevalent anomaly type
              was amount deviation, with 15 transactions exceeding historical baselines by more
              than 200%. The risk scoring model achieved 94.2% accuracy in identifying transactions
              that required manual review, with a decreasing risk trend of 12% compared to the
              previous audit period.
            </p>
          </div>
          <div>
            <p className="font-semibold text-gray-900 mb-2">Overall Risk Assessment:</p>
            <p>
              The audit reveals moderate-to-high risk exposure with 11.5% of transactions classified
              as high-risk. However, the decreasing trend in risk indicators suggests improved control
              effectiveness. Critical areas requiring immediate attention include vendor onboarding
              procedures, dual authorization enforcement for high-value transactions, and after-hours
              transaction monitoring.
            </p>
          </div>
          <div className="bg-blue-100 border-l-4 border-blue-600 rounded p-3 mt-4">
            <p className="text-xs font-bold text-blue-900 mb-1">AI CONFIDENCE & METHODOLOGY</p>
            <p className="text-xs text-blue-900">
              Model Accuracy: 94.2% | Algorithm: Ensemble ML (Random Forest + Neural Network) |
              Training Dataset: 50,000+ historical transactions | Last Model Update: April 2024
            </p>
          </div>
        </div>
      </div>

      {/* RPT-01: Risk Distribution (% High / Medium / Low) */}
      <div className="bg-white border-2 border-blue-300 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <TrendingUp className="w-6 h-6 text-blue-600" />
          <div className="flex-1">
            <h3 className="text-lg font-bold">Risk Distribution (% High / Medium / Low)</h3>
            <p className="text-xs text-gray-600 mt-1">Percentage breakdown of risk levels across all transactions</p>
          </div>
          <span className="px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-full">
            AI-GENERATED
          </span>
        </div>

        {/* Risk Percentage Summary Cards */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-red-50 border-2 border-red-400 rounded-lg p-4 text-center">
            <p className="text-xs font-semibold text-red-700 uppercase mb-2">High Risk</p>
            <p className="text-4xl font-bold text-red-600">{highRiskPercentage}%</p>
            <p className="text-sm text-red-700 mt-2">23 of {totalTransactions} transactions</p>
          </div>
          <div className="bg-yellow-50 border-2 border-yellow-400 rounded-lg p-4 text-center">
            <p className="text-xs font-semibold text-yellow-700 uppercase mb-2">Medium Risk</p>
            <p className="text-4xl font-bold text-yellow-600">{mediumRiskPercentage}%</p>
            <p className="text-sm text-yellow-700 mt-2">45 of {totalTransactions} transactions</p>
          </div>
          <div className="bg-green-50 border-2 border-green-400 rounded-lg p-4 text-center">
            <p className="text-xs font-semibold text-green-700 uppercase mb-2">Low Risk</p>
            <p className="text-4xl font-bold text-green-600">{lowRiskPercentage}%</p>
            <p className="text-sm text-green-700 mt-2">132 of {totalTransactions} transactions</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            {riskDistributionData && riskDistributionData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={riskDistributionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => {
                      const percent = entry.percent || 0;
                      return `${entry.name}: ${(percent * 100).toFixed(0)}%`;
                    }}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {riskDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center bg-gray-50 rounded">
                <p className="text-gray-500">No data available</p>
              </div>
            )}
          </div>
          <div className="flex flex-col justify-center space-y-3">
            {riskDistributionData.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: item.color }} />
                  <span className="font-medium text-gray-900">{item.name}</span>
                </div>
                <div className="text-right">
                  <div className="text-xl font-semibold text-gray-900">{item.value}</div>
                  <div className="text-xs text-gray-500">
                    {((item.value / 200) * 100).toFixed(1)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* RPT-01: List of Detected Anomalies */}
      <div className="bg-white border-2 border-blue-300 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center">
            <AlertCircle className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold">List of Detected Anomalies</h3>
            <p className="text-xs text-gray-600 mt-1">AI-identified irregularities and pattern deviations</p>
          </div>
          <span className="px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-full">
            AI-GENERATED
          </span>
        </div>

        {/* Detailed Anomaly List */}
        <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
          <h4 className="text-sm font-bold text-red-900 mb-3">COMPLETE ANOMALY LISTING</h4>
          <div className="space-y-3">
            {[
              { id: 'TXN-2024-0847', type: 'Amount Deviation', description: 'Payment of $245,000 exceeds vendor historical average by 340%', severity: 'High' },
              { id: 'TXN-2024-0923', type: 'Vendor Risk', description: 'New vendor with no prior transaction history, high amount ($89,500)', severity: 'High' },
              { id: 'TXN-2024-0856', type: 'Duplicate Pattern', description: 'Duplicate invoice number detected in different periods', severity: 'Medium' },
              { id: 'TXN-2024-0834', type: 'Timing Anomaly', description: 'Transaction processed at 11:47 PM, outside business hours', severity: 'Medium' },
              { id: 'TXN-2024-0791', type: 'Authorization Gap', description: 'High-value transaction missing secondary approval ($156,000)', severity: 'High' },
            ].map((anomaly, index) => (
              <div key={index} className="bg-white border-l-4 border-red-600 rounded p-3">
                <div className="flex items-start justify-between mb-1">
                  <p className="font-bold text-sm text-gray-900">{anomaly.id}</p>
                  <span className={`text-xs font-bold px-2 py-1 rounded ${
                    anomaly.severity === 'High'
                      ? 'bg-red-100 text-red-800'
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {anomaly.severity}
                  </span>
                </div>
                <p className="text-xs font-semibold text-red-700 mb-1">{anomaly.type}</p>
                <p className="text-sm text-gray-700">{anomaly.description}</p>
              </div>
            ))}
          </div>
        </div>
        {anomalyData && anomalyData.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={anomalyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="category" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#3B82F6" name="Anomaly Count" />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[300px] flex items-center justify-center bg-gray-50 rounded">
            <p className="text-gray-500">No anomaly data available</p>
          </div>
        )}
      </div>

        </div>
      </div>

      {/* COMBINED INPUT/OUTPUT SECTION: Human Review of AI Recommendations */}
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-400 rounded-lg p-1">
        <div className="flex items-center gap-3 px-5 py-3 bg-purple-600 text-white rounded-t-lg">
          <FileText className="w-6 h-6" />
          <div className="flex-1">
            <h3 className="font-bold text-lg">AI + HUMAN: Recommendations Review & Editing</h3>
            <p className="text-sm text-purple-100">AI-generated recommendations requiring human approval and editing</p>
          </div>
          <span className="px-3 py-1 bg-white text-purple-600 text-xs font-bold rounded-full">
            AI + HUMAN
          </span>
        </div>
        <div className="p-5">

      {/* RPT-02: Recommendations (AI-Generated + Editable) - Human Review & Control */}
      <div className="bg-white border-2 border-purple-300 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-gray-900 text-lg">Recommendations (AI-Generated + Editable)</h3>
            <p className="text-sm text-blue-700 font-medium mt-1">AI suggestions subject to human review and final approval</p>
          </div>
          <span className="px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-full">
            AI + HUMAN
          </span>
        </div>

        {/* Human Control Notice */}
        <div className="bg-amber-50 border-2 border-amber-400 rounded-lg p-4 mb-5">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-amber-900 mb-1">HUMAN OVERSIGHT REQUIRED</p>
              <p className="text-xs text-amber-800">
                All AI-generated recommendations must be reviewed, validated, and approved by qualified auditors
                before final report submission. Click the edit icon to modify any recommendation as needed.
                Final audit decisions remain under human control.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {recommendations.map((rec) => (
            <div key={rec.id} className="bg-white border-2 border-gray-300 rounded-lg p-5 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xs font-bold text-blue-600 bg-blue-100 px-2 py-1 rounded">
                      AI-GENERATED
                    </span>
                    <span
                      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold border-2 ${
                        rec.priority === 'High'
                          ? 'bg-red-100 text-red-800 border-red-400'
                          : rec.priority === 'Medium'
                          ? 'bg-yellow-100 text-yellow-800 border-yellow-400'
                          : 'bg-blue-100 text-blue-800 border-blue-400'
                      }`}
                    >
                      {rec.priority} Priority
                    </span>
                  </div>
                  {rec.isEditing ? (
                    <div className="space-y-3">
                      <div className="bg-amber-50 border border-amber-300 rounded p-2 mb-2">
                        <p className="text-xs font-semibold text-amber-800">
                          ✏️ EDITING MODE - Modify AI recommendation as needed
                        </p>
                      </div>
                      <textarea
                        value={rec.editedText}
                        onChange={(e) =>
                          setRecommendations(
                            recommendations.map((r) =>
                              r.id === rec.id ? { ...r, editedText: e.target.value } : r
                            )
                          )
                        }
                        className="w-full px-4 py-3 border-2 border-blue-400 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
                        rows={4}
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleSaveRecommendation(rec.id)}
                          className="px-5 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-bold shadow-md"
                        >
                          ✓ Save Changes (Human Approved)
                        </button>
                        <button
                          onClick={() => handleCancelEdit(rec.id)}
                          className="px-5 py-2.5 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors text-sm font-bold"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-700 leading-relaxed">{rec.text}</p>
                  )}
                </div>
                {!rec.isEditing && (
                  <button
                    onClick={() => handleEditRecommendation(rec.id)}
                    className="flex-shrink-0 p-3 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors border-2 border-blue-300"
                    title="Edit AI recommendation"
                  >
                    <Edit3 className="w-5 h-5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

        </div>
      </div>

      {/* INPUT SECTION: Professional Auditor Input */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-lg p-1">
        <div className="flex items-center gap-3 px-5 py-3 bg-amber-600 text-white rounded-t-lg">
          <Edit3 className="w-6 h-6" />
          <div className="flex-1">
            <h3 className="font-bold text-lg">INPUT: Professional Auditor Comments</h3>
            <p className="text-sm text-amber-100">Human auditor's final assessment and conclusions</p>
          </div>
          <span className="px-3 py-1 bg-white text-amber-600 text-xs font-bold rounded-full">
            INPUT
          </span>
        </div>
        <div className="p-5">

      {/* RPT-01: Auditor Comments (Human Professional Input) */}
      <div className="bg-white border-2 border-amber-300 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 bg-amber-600 rounded-lg flex items-center justify-center">
            <Edit3 className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-gray-900 text-lg">Auditor Comments (Human Professional Input)</h3>
            <p className="text-sm text-amber-700 font-medium mt-1">Final professional assessment and audit conclusions</p>
          </div>
          <span className="px-3 py-1 bg-amber-600 text-white text-xs font-bold rounded-full">
            INPUT
          </span>
        </div>

        {savedComments.length > 0 && (
          <div className="space-y-3 mb-5">
            <h4 className="text-sm font-bold text-amber-900 uppercase tracking-wide">Saved Auditor Comments:</h4>
            {savedComments.map((comment, index) => (
              <div key={index} className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-amber-600 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold text-sm">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="text-xs font-bold text-amber-700 mb-1">AUDITOR COMMENT #{index + 1}</p>
                    <p className="text-sm text-gray-700 leading-relaxed">{comment}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="space-y-3 pt-4 border-t-2 border-gray-300">
          <label className="block text-sm font-bold text-gray-700 uppercase tracking-wide">
            Add New Auditor Comment
          </label>
          <textarea
            value={auditorComment}
            onChange={(e) => setAuditorComment(e.target.value)}
            placeholder="Enter your professional assessment, conclusions, recommendations, or additional context that supplements the AI-generated findings..."
            className="w-full px-4 py-3 border-2 border-amber-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none resize-none bg-amber-50"
            rows={5}
          />
          <button
            onClick={handleAddComment}
            className="px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors font-bold shadow-md"
          >
            Add Auditor Comment
          </button>
        </div>
      </div>

        </div>
      </div>

      {/* Report Metadata */}
      <div className="bg-gray-50 border-2 border-gray-300 rounded-lg p-6">
        <h4 className="font-semibold mb-4">Report Information</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <p className="text-gray-600 mb-1">Report Period</p>
            <p className="font-medium text-gray-900">May 1-15, 2024</p>
          </div>
          <div>
            <p className="text-gray-600 mb-1">Generated</p>
            <p className="font-medium text-gray-900">May 17, 2024</p>
          </div>
          <div>
            <p className="text-gray-600 mb-1">Lead Auditor</p>
            <p className="font-medium text-gray-900">Sarah Chen, CPA</p>
          </div>
          <div>
            <p className="text-gray-600 mb-1">AI Model Version</p>
            <p className="font-medium text-gray-900">v2.4.1</p>
          </div>
        </div>
      </div>
    </div>
  );
}
