import { useState } from 'react';
import { FileCheck, Search, ClipboardList, FileText, Sparkles, Edit3, Users } from 'lucide-react';
import AuditPlanning from './components/AuditPlanning';
import EvidenceGathering from './components/EvidenceGathering';
import AuditExecution from './components/AuditExecution';
import Reporting from './components/Reporting';

type TabType = 'planning' | 'evidence' | 'execution' | 'reporting';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('planning');

  const tabs = [
    { id: 'planning' as TabType, name: 'Audit Planning', icon: ClipboardList },
    { id: 'evidence' as TabType, name: 'Evidence Gathering', icon: Search },
    { id: 'execution' as TabType, name: 'Audit Execution', icon: FileCheck },
    { id: 'reporting' as TabType, name: 'Reporting', icon: FileText },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="px-6 py-4">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">AI-Assisted Audit Management System</h1>
              <p className="text-sm text-gray-600 mt-1">
                Intelligent transaction analysis with human oversight and professional judgment
              </p>
            </div>
            {/* Legend */}
            <div className="flex gap-3 text-xs">
              <div className="flex items-center gap-2 px-3 py-2 bg-amber-50 border border-amber-300 rounded-lg">
                <Edit3 className="w-4 h-4 text-amber-600" />
                <span className="font-medium text-gray-700">Input</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-blue-50 border border-blue-300 rounded-lg">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <span className="font-medium text-gray-700">AI Output</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-purple-50 border border-purple-300 rounded-lg">
                <Users className="w-4 h-4 text-purple-600" />
                <span className="font-medium text-gray-700">AI + Human</span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="px-6">
          <div className="flex gap-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-3 font-medium text-sm transition-colors border-b-2 ${
                    activeTab === tab.id
                      ? 'text-blue-600 border-blue-600 bg-blue-50'
                      : 'text-gray-600 border-transparent hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.name}
                </button>
              );
            })}
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-6">
        {/* Welcome Banner - Only show on planning tab */}
        {activeTab === 'planning' && (
          <div className="mb-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg p-6 shadow-lg">
            <h2 className="text-xl font-bold mb-2">Welcome to the AI-Assisted Audit System</h2>
            <p className="text-blue-100 text-sm mb-4">
              This platform combines artificial intelligence with human expertise to deliver comprehensive,
              efficient audit analysis while maintaining professional oversight and accountability.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="bg-white/10 rounded-lg p-3 backdrop-blur">
                <p className="font-semibold mb-1">🎯 AI-Powered Risk Detection</p>
                <p className="text-xs text-blue-100">Machine learning identifies high-risk transactions automatically</p>
              </div>
              <div className="bg-white/10 rounded-lg p-3 backdrop-blur">
                <p className="font-semibold mb-1">👤 Human Oversight Central</p>
                <p className="text-xs text-blue-100">Professional auditors review, validate, and control all final decisions</p>
              </div>
              <div className="bg-white/10 rounded-lg p-3 backdrop-blur">
                <p className="font-semibold mb-1">📊 Explainable AI</p>
                <p className="text-xs text-blue-100">Transparent ML explanations support informed audit judgments</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'planning' && <AuditPlanning />}
        {activeTab === 'evidence' && <EvidenceGathering />}
        {activeTab === 'execution' && <AuditExecution />}
        {activeTab === 'reporting' && <Reporting />}
      </main>
    </div>
  );
}